<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if (0 === strpos($pathinfo, '/userapi')) {
            // app_groupapi_creategroup
            if ('/userapi/creategroup' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\GroupAPIController::creategroupAction',  '_route' => 'app_groupapi_creategroup',);
            }

            // app_userapi_createuser
            if ('/userapi/createuser' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::createuserAction',  '_route' => 'app_userapi_createuser',);
            }

            // app_groupapi_listgroup
            if ('/userapi/listgroup' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\GroupAPIController::listgroupAction',  '_route' => 'app_groupapi_listgroup',);
            }

            // app_userapi_listuser
            if ('/userapi/listuser' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::listuserAction',  '_route' => 'app_userapi_listuser',);
            }

            // app_groupapi_modifygroup
            if (0 === strpos($pathinfo, '/userapi/modifygroup') && preg_match('#^/userapi/modifygroup/(?P<gid>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_groupapi_modifygroup']), array (  '_controller' => 'AppBundle\\Controller\\GroupAPIController::modifygroupAction',));
            }

            if (0 === strpos($pathinfo, '/userapi/modifyuser')) {
                // app_userapi_modifyuseroldstyle
                if ('/userapi/modifyuseroldstyle' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::modifyuseroldstyleAction',  '_route' => 'app_userapi_modifyuseroldstyle',);
                }

                // app_userapi_modifyuser
                if (preg_match('#^/userapi/modifyuser/(?P<uid>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_userapi_modifyuser']), array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::modifyuserAction',));
                }

            }

            // app_groupapi_showgroup
            if (0 === strpos($pathinfo, '/userapi/showgroup') && preg_match('#^/userapi/showgroup/(?P<gid>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_groupapi_showgroup']), array (  '_controller' => 'AppBundle\\Controller\\GroupAPIController::showgroupAction',));
            }

            // app_userapi_showuser
            if (0 === strpos($pathinfo, '/userapi/showuser') && preg_match('#^/userapi/showuser/(?P<uid>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_userapi_showuser']), array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::showuserAction',));
            }

            if (0 === strpos($pathinfo, '/userapi/deletegroup')) {
                // app_groupapi_deletegroup
                if (preg_match('#^/userapi/deletegroup/(?P<gid>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_groupapi_deletegroup']), array (  '_controller' => 'AppBundle\\Controller\\GroupAPIController::deletegroupAction',));
                }

                // app_userapi_deletegroupfromuser
                if (0 === strpos($pathinfo, '/userapi/deletegroupfromuser') && preg_match('#^/userapi/deletegroupfromuser/(?P<uid>[^/]++)/(?P<gid>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_userapi_deletegroupfromuser']), array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::deletegroupfromuserAction',));
                }

            }

            // app_userapi_deleteuser
            if (0 === strpos($pathinfo, '/userapi/deleteuser') && preg_match('#^/userapi/deleteuser/(?P<uid>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_userapi_deleteuser']), array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::deleteuserAction',));
            }

            // app_userapi_addgrouptouser
            if (0 === strpos($pathinfo, '/userapi/addgrouptouser') && preg_match('#^/userapi/addgrouptouser/(?P<uid>[^/]++)/(?P<gid>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'app_userapi_addgrouptouser']), array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::addgrouptouserAction',));
            }

            // app_userapi_report
            if ('/userapi/report' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\UserAPIController::reportAction',  '_route' => 'app_userapi_report',);
            }

        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
