<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = [
        'homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_groupapi_creategroup' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\GroupAPIController::creategroupAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/creategroup',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_groupapi_listgroup' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\GroupAPIController::listgroupAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/listgroup',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_groupapi_modifygroup' => array (  0 =>   array (    0 => 'gid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\GroupAPIController::modifygroupAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'gid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/modifygroup',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_groupapi_showgroup' => array (  0 =>   array (    0 => 'gid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\GroupAPIController::showgroupAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'gid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/showgroup',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_groupapi_deletegroup' => array (  0 =>   array (    0 => 'gid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\GroupAPIController::deletegroupAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'gid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/deletegroup',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_createuser' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::createuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/createuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_listuser' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::listuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/listuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_modifyuseroldstyle' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::modifyuseroldstyleAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/modifyuseroldstyle',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_modifyuser' => array (  0 =>   array (    0 => 'uid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::modifyuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'uid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/modifyuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_showuser' => array (  0 =>   array (    0 => 'uid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::showuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'uid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/showuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_deleteuser' => array (  0 =>   array (    0 => 'uid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::deleteuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'uid',    ),    1 =>     array (      0 => 'text',      1 => '/userapi/deleteuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_addgrouptouser' => array (  0 =>   array (    0 => 'uid',    1 => 'gid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::addgrouptouserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'gid',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'uid',    ),    2 =>     array (      0 => 'text',      1 => '/userapi/addgrouptouser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_deletegroupfromuser' => array (  0 =>   array (    0 => 'uid',    1 => 'gid',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::deletegroupfromuserAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'gid',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'uid',    ),    2 =>     array (      0 => 'text',      1 => '/userapi/deletegroupfromuser',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_userapi_report' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\UserAPIController::reportAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/userapi/report',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    ];
        }
    }

    public function generate($name, $parameters = [], $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
